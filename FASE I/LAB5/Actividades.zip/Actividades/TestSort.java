public class TestSort {
    public static void showArray(int[] arr) {
        for (int i = 0; i < arr.length; i++) {
            System.out.print(arr[i] + " ");
        }
        System.out.println();
    }

    public static void main(String[] args) {
        int[] arr = { 35, 56, 31, 8, 57, 64, 74, 82, 62, 13, 50, 63, 21 };
        int[] arrs = { 35, 56, 31, 8, 57, 64, 74, 82, 62, 13, 50, 63, 21 };
        System.out.println("Original array:");
        showArray(arr);
        arr=arrs;
        System.out.println("bubbleSort array:");
        sort.bubbleSort(arr);
        showArray(arr);
        System.out.println("insertionSort array:");
        sort.insertionSort(arr);
        showArray(arr);
        System.out.println("selectionSort array:");
        sort.selectionSort(arr);
        showArray(arr);
        System.out.println("shellSort array:");
        sort.shellSort(arr);
        showArray(arr);
        arr=arrs;
        System.out.println("quickSort array:");
        sort.quickSort(arr, 0, arr.length - 1);
        showArray(arr);

    }
}
